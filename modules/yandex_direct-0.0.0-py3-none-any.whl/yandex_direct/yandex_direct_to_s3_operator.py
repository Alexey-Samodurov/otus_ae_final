from typing import Dict, Any, Sequence

from airflow.models import BaseOperator
from airflow.providers.amazon.aws.hooks.s3 import S3Hook

from yandex_direct.yandex_direct_hook import YandexDirectHook


class YandexDirectToS3Operator(BaseOperator):
    """
    Operator for getting data from Yandex Direct API and uploading it to S3

    :param yandex_direct_conn_id: Airflow connection id for Yandex Direct
    :param s3_conn_id: Airflow connection id for S3
    :param s3_bucket: S3-bucket name
    :param s3_key: S3 key. Template field
    :param yandex_direct_fields: List of fields for Yandex Direct API. All columns by report type can be found in
        https://yandex.ru/dev/direct/doc/reports/fields-list.html
    :param yandex_direct_report_type: Report type for Yandex Direct API. Can be 'ACCOUNT_PERFORMANCE_REPORT',
        'AD_PERFORMANCE_REPORT', 'AD_GROUP_PERFORMANCE_REPORT', 'CAMPAIGN_PERFORMANCE_REPORT',
        'CRITERIA_PERFORMANCE_REPORT', 'CUSTOM_REPORT', 'REACH_AND_FREQUENCY_PERFORMANCE_REPORT',
        'SEARCH_QUERY_PERFORMANCE_REPORT'
    :param yandex_direct_start_date: Date of the beginning of the data collection, in the format '%Y-%m-%d'.
        Template field
    :param yandex_direct_end_date: Date of the end of the data collection, in the format '%Y-%m-%d' in case of None, the
        end_date = start_date. Template field
    :param args: args for BaseOperator
    :param kwargs: kwargs for BaseOperator
    """

    template_fields: Sequence[str] = ('yandex_direct_start_date', 'yandex_direct_end_date', 's3_key')

    YELLOW = '#FFFF00'
    ui_color = YELLOW

    def __init__(self,
                 yandex_direct_conn_id: str,
                 s3_conn_id: str,
                 s3_bucket: str,
                 s3_key: str,
                 yandex_direct_fields: list,
                 yandex_direct_report_type: str,
                 yandex_direct_start_date: str,
                 yandex_direct_end_date: str = None,
                 *args,
                 **kwargs):
        super().__init__(*args, **kwargs)
        self._yandex_direct_conn_id = yandex_direct_conn_id
        self._s3_conn_id = s3_conn_id
        self.s3_bucket = s3_bucket
        self.s3_key = s3_key
        self.yandex_direct_fields = yandex_direct_fields
        self.yandex_direct_report_type = yandex_direct_report_type
        self.yandex_direct_start_date = yandex_direct_start_date
        self.yandex_direct_end_date = yandex_direct_end_date

    def execute(self, context: Dict[str, Any]) -> Any:
        yd_hook = YandexDirectHook(
            yandex_direct_fields=self.yandex_direct_fields,
            yandex_direct_report_type=self.yandex_direct_report_type,
            yandex_direct_conn_id=self._yandex_direct_conn_id,
            yandex_direct_start_date=self.yandex_direct_start_date,
            yandex_direct_end_date=self.yandex_direct_end_date,
        )
        s3_hook = S3Hook(aws_conn_id=self._s3_conn_id)
        s3_hook.load_bytes(
            bytes_data=yd_hook.get_data(),
            key=self.s3_key,
            bucket_name=self.s3_bucket,
            replace=True
        )
