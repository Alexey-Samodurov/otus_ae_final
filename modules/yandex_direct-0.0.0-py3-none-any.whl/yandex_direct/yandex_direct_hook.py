from typing import Tuple, Optional

from airflow.hooks.base import BaseHook

from yandex_direct.yandex_direct_connector import YandexDirectConnector


class YandexDirectHook(BaseHook):
    def __init__(self,
                 yandex_direct_fields: list,
                 yandex_direct_report_type: str,
                 yandex_direct_conn_id: str,
                 yandex_direct_start_date: str,
                 yandex_direct_end_date: str = None,
                 *args,
                 **kwargs):
        super().__init__(*args, **kwargs)
        self.yandex_direct_fields = yandex_direct_fields
        self.yandex_direct_report_type = yandex_direct_report_type
        self.yandex_direct_conn_id = yandex_direct_conn_id
        self.yandex_direct_start_date = yandex_direct_start_date
        self.yandex_direct_end_date = yandex_direct_end_date

    @property
    def get_conn(self) -> Tuple[Optional[str], str]:
        """Get Yandex Direct client login, token from Airflow"""
        conn = self.get_connection(self.yandex_direct_conn_id)
        extra = conn.extra_dejson
        login = extra.get('login', None)
        token = extra.get('token')
        return login, token

    def get_data(self) -> bytes:
        """Get bytes data from Yandex Direct API"""
        login, token = self.get_conn
        yd = YandexDirectConnector(
            fields=self.yandex_direct_fields,
            report_type=self.yandex_direct_report_type,
            start_date=self.yandex_direct_start_date,
            end_date=self.yandex_direct_end_date,
            client_login=login,
            token=token
        )
        for data in yd.get_iter_bytes():
            return data
