from dataclasses import dataclass, InitVar

from clickhouse_sqlalchemy.types import String, UInt32, UInt64, Float32, Date, Nullable


@dataclass()
class Direct:
    """Dataclass for Yandex Direct schema"""
    criterion: InitVar[bool] = None
    AdFormat: 'String' = 'AdFormat'
    AdGroupId: 'UInt64' = 'AdGroupId'
    AdGroupName: 'String' = 'AdGroupName'
    AdId: 'UInt64' = 'AdId'
    AdNetworkType: 'String' = 'AdNetworkType'
    Age: 'String' = 'Age'
    AvgClickPosition: 'Nullable(Float32)' = 'AvgClickPosition'
    AvgCpc: 'Nullable(Float32)' = 'AvgCpc'
    AvgEffectiveBid: 'Nullable(Float32)' = 'AvgEffectiveBid'
    AvgImpressionPosition: 'Nullable(Float32)' = 'AvgImpressionPosition'
    AvgPageviews: 'Nullable(Float32)' = 'AvgPageviews'
    AvgTrafficVolume: 'Nullable(Float32)' = 'AvgTrafficVolume'
    BounceRate: 'Nullable(Float32)' = 'BounceRate'
    Bounces: 'UInt64' = 'Bounces'
    CampaignId: 'UInt64' = 'CampaignId'
    CampaignName: 'String' = 'CampaignName'
    CampaignUrlPath: 'Nullable(String)' = 'CampaignUrlPath'
    CampaignType: 'String' = 'CampaignType'
    CarrierType: 'String' = 'CarrierType'
    Clicks: 'UInt32' = 'Clicks'
    ClientLogin: 'String' = 'ClientLogin'
    ConversionRate: 'Nullable(Float32)' = 'ConversionRate'
    Conversions: 'Nullable(Float32)' = 'Conversions'
    Cost: 'Float32' = 'Cost'
    CostPerConversion: 'Nullable(Float32)' = 'CostPerConversion'
    Criteria: 'String' = 'Criteria'
    CriteriaId: 'UInt64' = 'CriteriaId'
    CriteriaType: 'String' = 'CriteriaType'
    Ctr: 'Float32' = 'Ctr'
    Date: 'Date' = 'Date'
    Device: 'String' = 'Device'
    ExternalNetworkName: 'String' = 'ExternalNetworkName'
    Gender: 'String' = 'Gender'
    GoalsRoi: 'Nullable(Float32)' = 'GoalsRoi'
    Impressions: 'UInt32' = 'Impressions'
    IncomeGrade: 'String' = 'IncomeGrade'
    LocationOfPresenceId: 'UInt32' = 'LocationOfPresenceId'
    LocationOfPresenceName: 'String' = 'LocationOfPresenceName'
    MatchType: 'String' = 'MatchType'
    MobilePlatform: 'String' = 'MobilePlatform'
    Profit: 'Float32' = 'Profit'
    Revenue: 'Float32' = 'Revenue'
    RlAdjustmentId: 'Nullable(UInt32)' = 'RlAdjustmentId'
    Sessions: 'UInt32' = 'Sessions'
    Slot: 'String' = 'Slot'
    TargetingCategory: 'String' = 'TargetingCategory'
    TargetingLocationId: 'UInt64' = 'TargetingLocationId'
    TargetingLocationName: 'String' = 'TargetingLocationName'
    WeightedCtr: 'Float32' = 'WeightedCtr'
    WeightedImpressions: 'Float32' = 'WeightedImpressions'

    def __post_init__(self, criterion):
        if criterion:
            self.Criteria: 'String' = 'Criterion'
            self.CriteriaId: 'UInt32' = 'CriterionId'
            self.CriteriaType: 'String' = 'CriterionType'


