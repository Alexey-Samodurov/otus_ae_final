import json
import logging
from time import sleep
from urllib.error import HTTPError

import requests
from requests.adapters import HTTPAdapter
from urllib3 import Retry


class YandexDirectConnector:
    """
    Class for Yandex Direct API

    :param fields: List of fields for report of Yandex Direct. All columns by report type can be found in
    https://yandex.ru/dev/direct/doc/reports/fields-list.html
    :param report_type: Type of report. Can be 'ACCOUNT_PERFORMANCE_REPORT', 'AD_PERFORMANCE_REPORT',
    'AD_GROUP_PERFORMANCE_REPORT', 'CAMPAIGN_PERFORMANCE_REPORT', 'CRITERIA_PERFORMANCE_REPORT', 'CUSTOM_REPORT',
    'REACH_AND_FREQUENCY_PERFORMANCE_REPORT', 'SEARCH_QUERY_PERFORMANCE_REPORT'
    :param start_date: Date of the beginning of the data collection, in the format '%Y-%m-%d'
    :param end_date: Date of the end of the data collection, in the format '%Y-%m-%d' in case of None,
    end_date = start_date
    :param client_login: client login if requests sends from agency
    :param method: Methods for Yandex Direct API. Can be 'get', 'add', 'update', 'delete'
    add — add objects;
    update — change objects;
    delete — delete objects;
    get — get objects.
    :param sleep_timeout: sleep timeout between requests
    :param request_retries: max request retries
    :param request_retries_delay: max request retries delay in seconds
    """

    end_point = 'https://{}/'
    api_root = end_point + 'json/v5/reports'
    PRODUCTION_HOST = 'api.direct.yandex.com'

    def __init__(
            self,
            fields: list,
            report_type: str,
            start_date: str,
            token: str,
            end_date: str = None,
            client_login: str = None,
            method: str = 'get',
            sleep_timeout: int = 120,
            request_retries: int = 5,
            request_retries_delay: int = 5):

        if not isinstance(fields, list):
            self.fields = [fields]
        else:
            self.fields = fields
        self.report_type = report_type
        self.method = method
        self.start_date = start_date
        if end_date is None:
            self.end_date = start_date
        else:
            self.end_date = end_date
        self._client_agency = client_login
        self.sleep_timeout = sleep_timeout
        self._token = token
        self._request_retries = request_retries
        self._request_retries_delay = request_retries_delay

        assert self.report_type in (
            'ACCOUNT_PERFORMANCE_REPORT', 'AD_PERFORMANCE_REPORT', 'AD_GROUP_PERFORMANCE_REPORT',
            'CAMPAIGN_PERFORMANCE_REPORT', 'CRITERIA_PERFORMANCE_REPORT', 'CUSTOM_REPORT',
            'REACH_AND_FREQUENCY_PERFORMANCE_REPORT',
            'SEARCH_QUERY_PERFORMANCE_REPORT'), 'Wrong report type.'
        assert self.method in ('get', 'add', 'update', 'delete'), 'Wrong method.'

    @property
    def get_headers(self) -> dict:
        """Returns headers for Yandex Direct API"""
        headers = {
            'Authorization': 'Bearer ' + self._token,
            'processingMode': 'offline',
            'skipReportHeader': 'true',
            'skipReportSummary': 'true',
            'returnMoneyInMicros': 'false',
        }
        if self._client_agency:
            headers['Client-Login'] = self._client_agency
        return headers

    @property
    def get_main_url(self):
        """Generates url for Yandex Direct API"""
        return self.api_root.format(self.PRODUCTION_HOST)

    @property
    def get_payload(self) -> json:
        """Generates payload for Yandex Direct API"""
        payload = {
            "method": f'{self.method}',
            "params": {
                "SelectionCriteria": {
                    "DateFrom": self.start_date,
                    "DateTo": self.end_date
                },
                "FieldNames": self.fields,
                "DateRangeType": "CUSTOM_DATE",
                'ReportType': self.report_type,
                "ReportName": f'{self.report_type}_{self.start_date}-{self.end_date}_{"_".join(self.fields)[:10]}',
                "Format": "TSV",
                "IncludeVAT": "YES",
                "IncludeDiscount": "YES",
            }
        }
        return json.dumps(payload)

    @property
    def get_session(self) -> requests.Session:
        """Create session with requests"""
        session = requests.Session()
        retry = Retry(connect=self._request_retries, backoff_factor=self._request_retries_delay)
        adapter = HTTPAdapter(max_retries=retry)
        session.mount('https://', adapter)
        return session

    def build_report_task(self):
        with self.get_session as session:
            r = session.post(
                self.get_main_url,
                headers=self.get_headers,
                data=self.get_payload
            )
            logging.info(f'Build report task: {r.status_code}')

    def get_iter_bytes(self):
        self.build_report_task()
        with self.get_session as session:
            while True:
                r = session.get(
                    self.get_main_url,
                    headers=self.get_headers,
                    data=self.get_payload
                )
                if r.status_code == 200:
                    yield r.content
                    logging.info(f'Report in ready!')
                    break
                elif r.status_code in (201, 202):
                    logging.info(f'Report in queue: {r.status_code}')
                    sleep(self.sleep_timeout)
                    continue
                else:
                    raise HTTPError(f'Response is: {r.status_code}. Error: {r.text}')
