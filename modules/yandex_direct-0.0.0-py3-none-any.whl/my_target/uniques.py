from dataclasses import dataclass

from clickhouse_sqlalchemy.types import UInt32, DateTime, Float32


@dataclass(frozen=True)
class Uniques:
    id: "UInt32" = 'id'
    date: "DateTime" = 'date'
    reach: "UInt32" = 'uniques.reach'
    total: "UInt32" = 'uniques.total'
    increment: "UInt32" = 'uniques.increment'
    frequency: "Float32" = 'uniques.frequency'
