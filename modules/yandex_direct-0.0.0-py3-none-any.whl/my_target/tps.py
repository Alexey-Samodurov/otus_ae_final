from dataclasses import dataclass

from clickhouse_sqlalchemy.types import UInt32, DateTime, Float32


@dataclass(frozen=True)
class Tps:
    id: "UInt32" = 'id'
    date: "DateTime" = 'date'
    tps: "Float32" = 'tps.tps'
    tpd: "Float32" = 'tps.tpd'
