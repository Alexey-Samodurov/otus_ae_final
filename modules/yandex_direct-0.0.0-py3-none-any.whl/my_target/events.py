from dataclasses import dataclass

from clickhouse_sqlalchemy.types import UInt32, DateTime


@dataclass(frozen=True)
class Events:
    id: "UInt32" = 'id'
    date: "DateTime" = 'date'
    opening_app: "UInt32" = 'events.opening_app'
    opening_post: "UInt32" = 'events.opening_post'
    moving_into_group: "UInt32" = 'events.moving_into_group'
    clicks_on_external_url: "UInt32" = 'events.clicks_on_external_url'
    launching_video: "UInt32" = 'events.launching_video'
    comments: "UInt32" = 'events.comments'
    joinings: "UInt32" = 'events.joinings'
    likes: "UInt32" = 'events.likes'
    shares: "UInt32" = 'events.shares'
    votings: "UInt32" = 'events.votings'
    sending_form: "UInt32" = 'events.sending_form'
