from dataclasses import dataclass

from clickhouse_sqlalchemy.types import UInt32, String, Nullable


@dataclass(frozen=True)
class PackagesPadsInfo:
    id: "UInt32" = 'id'
    name: "String" = 'name'
    description: "Nullable(String)" = 'description'
    url_id: "Nullable(UInt32)" = 'eye_url.id'
    url: "Nullable(String)" = 'eye_url.url'
    url_description: "Nullable(String)" = 'eye_url.description'





