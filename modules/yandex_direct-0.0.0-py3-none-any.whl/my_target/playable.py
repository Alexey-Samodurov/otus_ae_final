from dataclasses import dataclass

from clickhouse_sqlalchemy.types import UInt32, DateTime


@dataclass(frozen=True)
class Playable:
    id: "UInt32" = 'id'
    date: "DateTime" = 'date'
    playable_game_open: "UInt32" = 'playable.playable_game_open'
    playable_game_close: "UInt32" = 'playable.playable_game_close'
    playable_call_to_action: "UInt32" = 'playable.playable_call_to_action'
