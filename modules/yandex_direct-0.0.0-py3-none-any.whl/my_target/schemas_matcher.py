from my_target.ad_offers import AdOffers
from my_target.all import All
from my_target.banners_info import BannersInfo
from my_target.base import Base
from my_target.ad_groups import AdGroups
from my_target.carousel import Carousel
from my_target.events import Events
from my_target.moat import Moat
from my_target.packages_pads_info import PackagesPadsInfo
from my_target.playable import Playable
from my_target.romi import Romi
from my_target.tps import Tps
from my_target.uniques import Uniques
from my_target.uniques_video import UniquesVideo
from my_target.video import Video
from my_target.groups_info import GroupsInfo

match_dict = {Base: 'base',
              Carousel: 'carousel',
              Events: 'events',
              Moat: 'moat',
              Playable: 'playable',
              Romi: 'romi',
              Tps: 'tps',
              Uniques: 'uniques',
              UniquesVideo: 'uniques_video',
              Video: 'video',
              AdOffers: 'ad_offers',
              All: 'all',
              BannersInfo: 'banners_info',
              AdGroups: 'ad_groups',
              GroupsInfo: 'groups_info',
              PackagesPadsInfo: 'packages_pads_info', }
