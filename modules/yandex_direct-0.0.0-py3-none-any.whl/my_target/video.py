from dataclasses import dataclass

from clickhouse_sqlalchemy.types import UInt32, DateTime, Float32


@dataclass(frozen=True)
class Video:
    id: "UInt32" = 'id'
    date: "DateTime" = 'date'
    video_started: "UInt32" = 'video.started'
    paused: "UInt32" = 'video.paused'
    resumed_after_pause: "UInt32" = 'video.resumed_after_pause'
    fullscreen_on: "UInt32" = 'video.fullscreen_on'
    fullscreen_off: "UInt32" = 'video.fullscreen_off'
    sound_turned_off: "UInt32" = 'video.sound_turned_off'
    sound_turned_on: "UInt32" = 'video.sound_turned_on'
    video_viewed_10_seconds: "UInt32" = 'video.viewed_10_seconds'
    video_viewed_25_percent: "UInt32" = 'video.viewed_25_percent'
    video_viewed_50_percent: "UInt32" = 'video.viewed_50_percent'
    video_viewed_75_percent: "UInt32" = 'video.viewed_75_percent'
    video_viewed_100_percent: "UInt32" = 'video.viewed_100_percent'
    video_viewed_10_seconds_rate: "Float32" = 'video.viewed_10_seconds_rate'
    video_viewed_25_percent_rate: "Float32" = 'video.viewed_25_percent_rate'
    video_viewed_50_percent_rate: "Float32" = 'video.viewed_50_percent_rate'
    video_viewed_75_percent_rate: "Float32" = 'video.viewed_75_percent_rate'
    video_viewed_100_percent_rate: "Float32" = 'video.viewed_100_percent_rate'
    video_depth_of_view: "Float32" = 'video.depth_of_view'
    started_cost: "Float32" = 'video.started_cost'
    video_viewed_10_seconds_cost: "Float32" = 'video.viewed_10_seconds_cost'
    video_viewed_25_percent_cost: "Float32" = 'video.viewed_25_percent_cost'
    video_viewed_50_percent_cost: "Float32" = 'video.viewed_50_percent_cost'
    video_viewed_75_percent_cost: "Float32" = 'video.viewed_75_percent_cost'
    video_viewed_100_percent_cost: "Float32" = 'video.viewed_100_percent_cost'
