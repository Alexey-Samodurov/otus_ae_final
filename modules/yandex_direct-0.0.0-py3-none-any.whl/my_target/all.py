from dataclasses import dataclass

from clickhouse_sqlalchemy.types import UInt32, DateTime
from my_target.ad_offers import AdOffers
from my_target.base import Base
from my_target.carousel import Carousel
from my_target.events import Events
from my_target.moat import Moat
from my_target.playable import Playable
from my_target.romi import Romi
from my_target.tps import Tps
from my_target.uniques import Uniques
from my_target.uniques_video import UniquesVideo
from my_target.video import Video


@dataclass(frozen=True)
class All(Base, Carousel, Events, Moat, Playable, Romi, Tps, Uniques, UniquesVideo, Video, AdOffers):
    id: "UInt32" = 'id'
    date: "DateTime" = 'date'


