from dataclasses import dataclass

from clickhouse_sqlalchemy.types import UInt32, DateTime, Float32


@dataclass(frozen=True)
class AdOffers:
    id: "UInt32" = 'id'
    date: "DateTime" = 'date'
    ad_offers: "UInt32" = 'ad_offers.offer_postponed'
    upload_receipt: "UInt32" = 'ad_offers.upload_receipt'
    earn_offer_rewards: "UInt32" = 'ad_offers.earn_offer_rewards'