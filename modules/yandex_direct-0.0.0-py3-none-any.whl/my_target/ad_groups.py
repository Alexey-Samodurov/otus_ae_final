from dataclasses import dataclass

from clickhouse_sqlalchemy.types import UInt32, String


@dataclass(frozen=True)
class AdGroups:
    id: "UInt32" = 'id'
    name: "String" = 'name'
    package_id: "UInt32" = 'package_id'



