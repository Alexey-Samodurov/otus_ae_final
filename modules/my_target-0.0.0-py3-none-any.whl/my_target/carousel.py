from dataclasses import dataclass

from clickhouse_sqlalchemy.types import UInt32, DateTime, Float32


@dataclass(frozen=True)
class Carousel:
    id: "UInt32" = 'id'
    date: "DateTime" = 'date'
    slide_1_clicks: "UInt32" = 'carousel.slide_1_clicks'
    slide_1_shows: "UInt32" = 'carousel.slide_1_shows'
    slide_2_clicks: "UInt32" = 'carousel.slide_2_clicks'
    slide_2_shows: "UInt32" = 'carousel.slide_2_shows'
    slide_3_clicks: "UInt32" = 'carousel.slide_3_clicks'
    slide_3_shows: "UInt32" = 'carousel.slide_3_shows'
    slide_4_clicks: "UInt32" = 'carousel.slide_4_clicks'
    slide_4_shows: "UInt32" = 'carousel.slide_4_shows'
    slide_5_clicks: "UInt32" = 'carousel.slide_5_clicks'
    slide_5_shows: "UInt32" = 'carousel.slide_5_shows'
    slide_6_clicks: "UInt32" = 'carousel.slide_6_clicks'
    slide_6_shows: "UInt32" = 'carousel.slide_6_shows'
    slide_1_ctr: "Float32" = 'carousel.slide_1_ctr'
    slide_2_ctr: "Float32" = 'carousel.slide_2_ctr'
    slide_3_ctr: "Float32" = 'carousel.slide_3_ctr'
    slide_4_ctr: "Float32" = 'carousel.slide_4_ctr'
    slide_5_ctr: "Float32" = 'carousel.slide_5_ctr'
    slide_6_ctr: "Float32" = 'carousel.slide_6_ctr'

