from dataclasses import dataclass

from clickhouse_sqlalchemy.types import UInt32


@dataclass(frozen=True)
class BannersInfo:
    ad_group_id: "UInt32" = 'ad_group_id'
    campaign_id: "UInt32" = 'campaign_id'
    id: "UInt32" = 'id'
    moderation_status: "Enum('allowed', 'pending', 'banned')" = 'moderation_status'
