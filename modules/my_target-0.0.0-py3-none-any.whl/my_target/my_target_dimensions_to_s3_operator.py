import io
from typing import Dict, Any, Sequence

from airflow.models import BaseOperator
from airflow.providers.amazon.aws.hooks.s3 import S3Hook

from my_target.my_target_hook import MyTargetHook


class MyTargetDimensionsToS3Operator(BaseOperator):
    """
    Operator for MyTarget API dimensions data from DataFrame to S3

    :param my_target_conn_id: My Target API connection id from Airflow
    :param s3_conn_id: S3 connection id from Airflow
    :param s3_bucket: S3 bucket name
    :param s3_key: S3 key name. Template field
    :param my_target_start_date: Start date for MyTarget API. Template field
    :param my_target_end_date: End date for MyTarget API. Tamplate field
    :param my_target_type_of_data: Type of API data, can bee banners|ad_groups|ad_plans|users
    :param my_target_metrics: metrics: String, list or tuple of metrics need to collect from API, can be like
        all, base, events, uniques, video, carousel, tps, moat, playable, romi
    :param my_target_dimension_name: dimension name: String, list or tuple of dimension name need to collect from API, can be like
        'banners_info', 'campaigns_info', 'packages_pads_info', 'groups_info'
    :param args: BaseOperator args
    :param kwargs: BaseOperator kwargs
    """
    template_fields: Sequence[str] = ('my_target_start_date', 'my_target_end_date', 's3_key')

    RED = '#FF9090'
    ui_color = RED

    def __init__(self,
                 my_target_conn_id: str,
                 s3_conn_id: str,
                 s3_bucket: str,
                 s3_key: str,
                 my_target_start_date: str,
                 my_target_end_date: str,
                 my_target_type_of_data: str,
                 my_target_metric: str = None,
                 my_target_dimension_name: str = None,
                 *args,
                 **kwargs):
        super().__init__(*args, **kwargs)
        self._my_target_conn_id = my_target_conn_id
        self._s3_conn_id = s3_conn_id
        self.s3_bucket = s3_bucket
        self.s3_key = s3_key
        self.my_target_start_date = my_target_start_date
        self.my_target_end_date = my_target_end_date
        self.my_target_type_of_data = my_target_type_of_data
        self.my_target_metric = my_target_metric
        self.my_target_dimension_name = my_target_dimension_name

    def execute(self, context: Dict[str, Any]) -> Any:
        mt_hook = MyTargetHook(
            my_target_conn_id=self._my_target_conn_id,
            my_target_start_date=self.my_target_start_date,
            my_target_end_date=self.my_target_end_date,
            my_target_type_of_data=self.my_target_type_of_data,
            my_target_metric=self.my_target_metric,
            my_target_dimension_name=self.my_target_dimension_name
        )
        s3_hook = S3Hook(aws_conn_id=self._s3_conn_id)
        with io.BytesIO() as buffer:
            mt_hook.get_dimensions_data().to_csv(buffer, index=False)
            s3_hook.load_bytes(
                bytes_data=buffer.getvalue(),
                key=self.s3_key,
                bucket_name=self.s3_bucket,
                replace=True
            )
