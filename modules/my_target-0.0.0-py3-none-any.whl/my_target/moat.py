from dataclasses import dataclass

from clickhouse_sqlalchemy.types import UInt32, DateTime, Float32


@dataclass(frozen=True)
class Moat:
    id: "UInt32" = 'id'
    date: "DateTime" = 'date'
    impressions: "UInt32" = 'moat.impressions'
    in_view: "UInt32" = 'moat.in_view'
    never_focused: "UInt32" = 'moat.never_focused'
    never_visible: "UInt32" = 'moat.never_visible'
    never_50_perc_visible: "UInt32" = 'moat.never_50_perc_visible'
    never_1_sec_visible: "UInt32" = 'moat.never_1_sec_visible'
    human_impressions: "UInt32" = 'moat.human_impressions'
    impressions_analyzed: "UInt32" = 'moat.impressions_analyzed'
    in_view_percent: "Float32" = 'moat.in_view_percent'
    human_and_viewable_perc: "Float32" = 'moat.human_and_viewable_perc'
    never_focused_percent: "Float32" = 'moat.never_focused_percent'
    never_visible_percent: "Float32" = 'moat.never_visible_percent'
    never_50_perc_visible_percent: "Float32" = 'moat.never_50_perc_visible_percent'
    never_1_sec_visible_percent: "Float32" = 'moat.never_1_sec_visible_percent'
    in_view_diff_percent: "Float32" = 'moat.in_view_diff_percent'
    active_in_view_time: "Float32" = 'moat.active_in_view_time'
    attention_quality: "Float32" = 'moat.attention_quality'