import contextlib
import logging
from pathlib import Path
from typing import Union, Optional, Generator, Dict
from urllib.parse import urlparse

import requests
from requests.adapters import HTTPAdapter
from urllib3 import Retry


class SupersetConnector:
    """
    Superset API connector.

    :param ss_url: Superset url. Example http://127.0.0.1:8088
    :param username: Superset username
    :param password: Superset password
    :param request_retries_delay: Delay between retries in seconds. Default: 5
    :param request_retries: Maximum tries of retries. Default: 2
    """
    API_URL = '/api/v1'

    def __init__(self,
                 ss_url: str,
                 username: str,
                 password: str,
                 request_retries_delay: int = 5,
                 request_retries: int = 2):
        self.ss_url = ss_url
        self._username = username
        self._password = password
        self._access_token = self.get_access_token
        self.request_retries_delay = request_retries_delay
        self.request_retries = request_retries

    @property
    def get_parsed_url(self) -> str:
        parsed = urlparse(self.ss_url)
        protocol = parsed.scheme
        netloc = parsed.netloc
        return f'{protocol}://{netloc}'

    @property
    def get_access_token(self) -> str:
        """
        Get access token from Superset API
        :return: access token
        """
        url = f'{self.get_parsed_url}{self.API_URL}/security/login'
        payload = {"password": self._password,
                   "provider": "db",
                   "refresh": True,
                   "username": self._username}
        response = requests.post(url, json=payload)
        logging.info(f'{response.json()}')
        return response.json()['access_token']

    @property
    def get_csrf_token(self) -> str:
        """
        Get csrf token from Superset API
        :return: csrf token
        """
        url = f'{self.get_parsed_url}{self.API_URL}/security/csrf_token'
        with self.get_session as session:
            response = session.get(url, headers={"Content-Type": "application/json",
                                                 "Authorization": f"Bearer {self._access_token}"})
            logging.info(f'Get csrf token: {response.json()}')
            return response.json()['result']

    @property
    def get_session_headers(self) -> dict:
        return {'accept': 'application/json',
                "X-CSRFToken": f"{self.get_csrf_token}",
                "Authorization": f"Bearer {self._access_token}"}

    @property
    def get_session(self) -> requests.Session:
        """
        Create session with requests
        :return: session
        """
        session = requests.Session()
        retry = Retry(connect=self.request_retries, backoff_factor=self.request_retries_delay)
        adapter = HTTPAdapter(max_retries=retry)
        session.mount('http://', adapter)
        session.mount('https://', adapter)
        return session

    @contextlib.contextmanager
    def read_zip_config(self, file_path: Union[str, Path]) -> Generator:
        """
        Read ZIP archive with dashboards config
        :param file_path: Path to ZIP archive with dashboards config
        :return: generator with dict of config
        """
        with open(file_path, 'rb') as file:
            yield {'formData': (str(file_path), file, 'application/json')}

    def get_dashboards_id(self) -> Dict[str, int]:
        """Get all dashboards names and id from Superset, as dictionary format {dashboard_name: dashboard_id}"""
        url = f'{self.get_parsed_url}{self.API_URL}/dashboard'
        with self.get_session as session:
            session.headers = self.get_session_headers
            response = session.get(url=url)
            return {dashboard['dashboard_title']: dashboard['id'] for dashboard in response.json()['result']}

    def import_dashboards(self,
                          zip_config_path: Union[str, Path],
                          overwrite: str = 'true',
                          passwords: Optional[str] = None) -> None:
        """
        Import dashboard of many dashboards to Superset from ZIP archive. The ZIP archive should include databases,
        datasets, charts and dashboards configs.

        :param zip_config_path: Path to ZIP archive with dashboards config. Can include multi dashboards.
        :param overwrite: Overwrite existing dashboards? Can be 'true' or 'false'. By default, 'true'.
        :param passwords: Dict map of passwords for each featured database in the ZIP file.
            If the ZIP includes a database config in the path databases/MyDatabase.yaml, the password should be provided
            in the following format: '{"databases/MyDatabase.yaml": "my_password"}'.
            By default, no password is provided.
        """
        url = f'{self.get_parsed_url}{self.API_URL}/dashboard/import/'
        request_body = {'overwrite': overwrite}
        if passwords:
            request_body['passwords'] = passwords
        with self.get_session as session:
            with self.read_zip_config(zip_config_path) as files:
                session.headers = self.get_session_headers
                session.headers.update({'Referer': url})
                response = session.post(url=url, files=files, data=request_body)
                if response.status_code == 200:
                    print(f'Import complete: {response.text}')
                else:
                    print(f'Import error: {response.text}')

    def export_dashboards(self, dashboard_ids: list[int]) -> bytes:
        """
        Export dashboard or many dashboards from Superset to ZIP archive as bytes

        :param dashboard_ids: List of dashboard integers ids, as example: [1, 2, 3]
        :return: bytes of ZIP archive
        """
        url = f'{self.get_parsed_url}{self.API_URL}/dashboard/export/'
        with self.get_session as session:
            session.headers = self.get_session_headers
            session.headers.update({'Referer': url})
            response = session.get(url=url, params={'q': '{}'.format(dashboard_ids)})
            return response.content
