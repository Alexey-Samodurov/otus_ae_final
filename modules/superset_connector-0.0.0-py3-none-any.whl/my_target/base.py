from dataclasses import dataclass

from clickhouse_sqlalchemy.types import UInt32, DateTime, Float32


@dataclass(frozen=True)
class Base:
    id: "UInt32" = 'id'
    date: "DateTime" = 'date'
    shows: "UInt32" = 'base.shows'
    clicks: "UInt32" = 'base.clicks'
    goals: "UInt32" = 'base.goals'
    spent: "Float32" = 'base.spent'
    cpm: "Float32" = 'base.cpm'
    cpc: "Float32" = 'base.cpc'
    cpa: "Float32" = 'base.cpa'
    ctr: "Float32" = 'base.ctr'
    cr: "Float32" = 'base.cr'