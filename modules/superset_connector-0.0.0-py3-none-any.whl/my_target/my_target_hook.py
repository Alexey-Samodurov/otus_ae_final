from dataclasses import fields
from typing import Tuple

import pandas as pd
from airflow.hooks.base import BaseHook

from my_target.my_target_connector import MyTargetConnector
from my_target.schemas_matcher import match_dict


class MyTargetHook(BaseHook):
    """
    Hook for MyTarget API

    :param my_target_conn_id: Connection id from Airflow
    :param my_target_start_date: Start date for MyTarget API
    :param my_target_end_date: End date for MyTarget API
    :param my_target_type_of_data: Type of API data, can bee campaigns, banners or users
    :param my_target_metrics: metrics: String, list or tuple of metrics need to collect from API, can be like
        all, base, events, uniques, video, carousel, tps, moat, playable, romi
    :param my_target_dimension_name: dimensions: String dimension need to collect from API, can be like
        can be like campaigns_info, banners_info, packages_pads_info
    :param args: BaseHook args
    :param kwargs: BaseHook kwargs
    """

    def __init__(self,
                 my_target_conn_id: str,
                 my_target_start_date: str,
                 my_target_end_date: str,
                 my_target_type_of_data: str,
                 my_target_metric: str,
                 my_target_dimension_name: str = None,
                 *args,
                 **kwargs):
        super().__init__(*args, **kwargs)
        self._my_target_conn_id = my_target_conn_id
        self.my_target_start_date = my_target_start_date
        self.my_target_end_date = my_target_end_date
        self.my_target_type_of_data = my_target_type_of_data
        self.my_target_metric = my_target_metric
        self.my_target_dimension_name = my_target_dimension_name

    @property
    def get_conn(self) -> Tuple[str, str, str]:
        """Get MyTarget token from Airflow"""
        conn = self.get_connection(self._my_target_conn_id)
        extra = conn.extra_dejson
        client_id = extra.get('client_id', None)
        client_secret = extra.get('client_secret', None)
        access_token = extra.get('access_token', None)
        return client_id, client_secret, access_token

    def get_data_from_my_target(self) -> pd.DataFrame:
        """Get data from MyTarget API"""
        mt = MyTargetConnector(
            client_id=self.get_conn[0],
            client_secret=self.get_conn[1],
            access_token=self.get_conn[2],
            start_date=self.my_target_start_date,
            end_date=self.my_target_end_date,
            type_of_data=self.my_target_type_of_data,
            metrics=self.my_target_metric
        )
        tot_df = pd.DataFrame()
        for client in [x['user']['id'] for x in mt.get_active_agency_clients()]:
            mt = MyTargetConnector(
                client_id=self.get_conn[0],
                client_secret=self.get_conn[1],
                access_token=self.get_conn[2],
                start_date=self.my_target_start_date,
                end_date=self.my_target_end_date,
                type_of_data=self.my_target_type_of_data,
                metrics=self.my_target_metric,
                agency_client_id=client
            )
            tot_df = tot_df.append(mt.collect_data_as_dataframe())
        for cls, name in match_dict.items():
            print(cls, name, self.my_target_metric)
            if name == self.my_target_metric:
                tot_df = tot_df.rename({x.default: x.name for x in fields(cls())}, axis=1)[[x.name for x
                                                                                           in fields(cls())]]
        return tot_df

    def get_dimensions_data(self) -> pd.DataFrame:
        """Get dimensions data from MyTarget API"""
        mt = MyTargetConnector(
            client_id=self.get_conn[0],
            client_secret=self.get_conn[1],
            access_token=self.get_conn[2],
            start_date=self.my_target_start_date,
            end_date=self.my_target_end_date,
            type_of_data=self.my_target_type_of_data,
            metrics=self.my_target_metric
        )
        tot_df = pd.DataFrame()
        for client in [x['user']['id'] for x in mt.get_active_agency_clients()]:
            mt = MyTargetConnector(
                client_id=self.get_conn[0],
                client_secret=self.get_conn[1],
                access_token=self.get_conn[2],
                start_date=self.my_target_start_date,
                end_date=self.my_target_end_date,
                type_of_data=self.my_target_type_of_data,
                metrics=self.my_target_metric,
                agency_client_id=client
            )
            if self.my_target_dimension_name == 'packages_pads_info':
                tot_df = tot_df.append(pd.json_normalize(mt.get_packages_pads_info()))
            else:
                tot_df = tot_df.append(pd.json_normalize(mt.get_type_of_data_info()))
        return tot_df
