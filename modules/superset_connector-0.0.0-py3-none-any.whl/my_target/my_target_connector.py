import json
import logging
from typing import Union, Optional, List

import pandas as pd
import requests
from requests.adapters import HTTPAdapter
from urllib3 import Retry


class MyTargetConnector:
    """
    Class for working with MyTarget API and getting data from it for further processing.
    If you don`t have client_id and client_secret, you must use access_token otherwise token will bee generate.

    :param start_date: Date of the beginning of the data collection, in the format '%Y-%m-%d'
    :param type_of_data: Type of API data, can bee banners|ad_groups|ad_plans|users
    :param metrics: String, list or tuple of metrics need to collect from API, can be like
    all, base, events, uniques, video, carousel, tps, moat, playable, romi
    :param client_id: Client ID of the application
    :param client_secret: API token of the application
    :param end_date: Date of the end of the data collection, in the format '%Y-%m-%d'
    :param access_token: Agency Client Credentials Grant token taken from json file with refresh token
    :param agency_client_id: ID of the agency client, you can get list of agency clients from method .get_active_agency_clients()
    :param limit_of_campaigns_ids: Limit of campaigns ids in one request, by default 250 elements
    :param request_retries: numbers of try if request failed
    :param request_retries_delay: delay in second between requests
    """
    END_POINT = 'https://{}/'
    API_ROOT = END_POINT + 'api/'
    PRODUCTION_HOST = 'target.my.com'
    headers = {
        'Host': 'target.my.com',
        'Content-Type': 'application/x-www-form-urlencoded'
    }

    def __init__(
            self,
            start_date: str,
            type_of_data: str,
            metrics: Union[str, list, tuple] = 'all',
            client_id: Optional[str] = None,
            client_secret: Optional[str] = None,
            end_date: Optional[str] = None,
            access_token: Optional[str] = None,
            agency_client_id: Optional[str] = None,
            limit_of_campaigns_ids: int = 250,
            request_retries: int = 5,
            request_retries_delay: int = 5
    ):
        self.start_date = start_date
        self.type_of_data = type_of_data
        self.metrics = metrics
        self._client_id = client_id
        self._client_secret = client_secret
        self.end_date = end_date if end_date else self.start_date
        self._access_token = access_token
        self._agency_client_id = agency_client_id
        self._limit_of_campaigns_ids = limit_of_campaigns_ids
        self.request_retries = request_retries
        self.request_retries_delay = request_retries_delay

        assert all([x is not None for x in (self._client_id, self._client_secret, self._access_token)]) is not True, '\
        Must be (client_id, client_secret not Null) or access_token not Null'
        assert self.type_of_data in (
            'banners', 'ad_groups', 'ad_plans', 'users'), 'Must be equal banners, ad_groups, ad_plans, users'

    def __repr__(self):
        """Return a string representation of the object."""
        return f"""Set type: {self.type_of_data!r}, 
        set metrics: {self.metrics!r}, 
        set start date: {self.start_date!r}, 
        set end date: {self.end_date!r}"""

    @property
    def get_main_url(self) -> str:
        """Generate main url"""
        return self.API_ROOT.format(self.PRODUCTION_HOST)

    @property
    def get_metrics_str(self) -> str:
        """Generate metrics string for url"""
        if isinstance(self.metrics, str):
            return self.metrics
        else:
            return ','.join(self.metrics)

    @property
    def get_end_date(self) -> str:
        """Set end date if none then equal start_date"""
        return self.start_date if not self.end_date else self.end_date

    @property
    def get_session(self) -> requests.Session:
        """Create session with requests"""
        session = requests.Session()
        retry = Retry(connect=self.request_retries, backoff_factor=self.request_retries_delay)
        adapter = HTTPAdapter(max_retries=retry)
        session.mount('https://', adapter)
        return session

    def generate_agency_token(self):
        """Generate agency token"""
        self.del_agency_token()
        url = '{}v2/oauth2/token.json'.format(self.get_main_url)
        with self.get_session.post(
                url,
                headers=self.headers,
                data='grant_type=client_credentials&client_id={}&client_secret={}'.format(
                    self._client_id,
                    self._client_secret
                )
        ) as r:
            if r.status_code == 200:
                logging.info(f'Generate agency token, responce is: {r.status_code}')
                return r.json()['access_token']
            else:
                logging.error(f'Response is: {r.status_code}. Error: {r.text}')

    def del_agency_token(self):
        """Delete used agency token"""
        url = '{}v2/oauth2/token/delete.json'.format(self.get_main_url)
        with self.get_session.post(
                url,
                headers=self.headers,
                data='client_id={}&client_secret={}'.format(
                    self._client_id,
                    self._client_secret
                )
        ) as r:
            if r.status_code == 204:
                logging.info(f'Deleting agency token, responce is: {r.status_code}')
            else:
                logging.error(f'Response is: {r.status_code}. Error: {r.text}')

    def generate_client_token(self):
        """Generate client token from API"""
        self.del_client_token()
        url = '{}v2/oauth2/token.json'.format(self.get_main_url)
        with self.get_session.post(
                url,
                headers=self.headers,
                data='grant_type=agency_client_credentials&client_id={}&client_secret={}&agency_client_id={}'.format(
                    self._client_id,
                    self._client_secret,
                    self._agency_client_id

                )
        ) as r:
            if r.status_code == 200:
                logging.info(f'Generate client token, responce is: {r.status_code}')
                return r.json()['access_token']
            else:
                logging.error(f'Response is: {r.status_code}. Error: {r.text}')

    def del_client_token(self):
        """Delete used client token"""
        url = '{}v2/oauth2/token/delete.json'.format(self.get_main_url)
        with self.get_session.post(url,
                                   headers=self.headers,
                                   data='client_id={}&client_secret={}&user_id={}'.format(
                                       self._client_id,
                                       self._client_secret,
                                       self._agency_client_id
                                   )
                                   ) as r:
            if r.status_code == 204:
                logging.info(f'Deleting client token, responce is: {r.status_code}')
            else:
                logging.error(f'Response is: {r.status_code}. Error: {r.text}')

    def update_agency_token(self):
        """Update agency token in headers of request"""
        if self._access_token:
            return self.headers.update({'Authorization': 'Bearer {}'.format(self._access_token)})
        else:
            return self.headers.update({'Authorization': 'Bearer {}'.format(self.generate_agency_token())})

    def update_client_token(self):
        """Update client token in headers of request"""
        if self._access_token:
            return self.headers.update({'Authorization': 'Bearer {}'.format(self._access_token)})
        else:
            return self.headers.update({'Authorization': 'Bearer {}'.format(self.generate_client_token())})

    def get_type_of_data_info(self) -> List[dict]:
        """Get campaigns information data from API as list of dicts"""
        result = []
        offset = 0
        self.update_client_token()
        while True:
            url = '{}v2/{}.json?limit={}&offset={}'.format(self.get_main_url,
                                                           self.type_of_data,
                                                           self._limit_of_campaigns_ids,
                                                           offset)
            logging.info(url)
            with self.get_session.get(url, headers=self.headers) as r:
                lst = r.json()['items']
                if not lst:
                    break
                for item in lst:
                    result.append(item)
                offset += len(lst)
        return result

    def get_packages_pads_info(self) -> List[dict]:
        """Get information about the sites that are used in the default package targeting as list of dicts"""
        self.update_client_token()
        url = '{}v2/packages_pads.json'.format(self.get_main_url)
        logging.info(url)
        with self.get_session.get(url, headers=self.headers) as r:
            result = r.json()['items']
        return result

    def get_active_agency_clients(self) -> List[dict]:
        """Get client ids list from API"""
        self.update_agency_token()
        url = '{}v2/agency/clients.json'.format(self.get_main_url)
        with self.get_session.get(url, headers=self.headers) as r:
            if r.status_code == 200:
                logging.info(f'Get client id, response is: {r.status_code}')
                return [x for x in r.json()['items'] if
                        x.get('status') == 'active' and x.get('user').get('status') == 'active']
            else:
                logging.error(f'Response is: {r.status_code}. Error: {r.text}')

    def collect_data_as_json(self) -> json:
        """Returns the json with daily statistics for the selected period for campaigns, banners or users"""
        self.update_client_token()
        url = '{}v2/statistics/{}/day.json?date_from={}&date_to={}&metrics={}'.format(
            self.get_main_url,
            self.type_of_data,
            self.start_date,
            self.get_end_date,
            self.get_metrics_str
        )
        with self.get_session.get(url, headers=self.headers) as r:
            if r.status_code == 200:
                logging.info(f'Get json data, response is: {r.status_code}')
                return r.json()['items']

            else:
                logging.error(f'Response is: {r.status_code}. Error: {r.text}')

    def collect_data_as_dataframe(self) -> pd.DataFrame:
        """Returns the dataframe with daily statistics for the selected period for campaigns, banners or users"""
        json_data = self.collect_data_as_json()
        if len(json_data) > 0:
            return pd.json_normalize(json_data, record_path='rows', meta='id')
        else:
            return pd.DataFrame()
