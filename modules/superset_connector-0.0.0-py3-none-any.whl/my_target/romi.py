from dataclasses import dataclass

from clickhouse_sqlalchemy.types import UInt32, DateTime, Float32


@dataclass(frozen=True)
class Romi:
    id: "UInt32" = 'id'
    date: "DateTime" = 'date'
    value: "Float32" = 'romi.value'
    romi: "Float32" = 'romi.romi'
    adv_cost_share: "Float32" = 'romi.adv_cost_share'