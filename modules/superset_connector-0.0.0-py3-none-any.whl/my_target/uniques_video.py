from dataclasses import dataclass

from clickhouse_sqlalchemy.types import UInt32, DateTime, Float32


@dataclass(frozen=True)
class UniquesVideo:
    id: "UInt32" = 'id'
    date: "DateTime" = 'date'
    uniques_video_started: "UInt32" = 'uniques_video.started'
    uniques_video_viewed_10_seconds: "UInt32" = 'uniques_video.viewed_10_seconds'
    uniques_video_viewed_25_percent: "UInt32" = 'uniques_video.viewed_25_percent'
    uniques_video_viewed_50_percent: "UInt32" = 'uniques_video.viewed_50_percent'
    uniques_video_viewed_75_percent: "UInt32" = 'uniques_video.viewed_75_percent'
    uniques_video_viewed_100_percent: "UInt32" = 'uniques_video.viewed_100_percent'
    uniques_video_viewed_10_seconds_rate: "Float32" = 'uniques_video.viewed_10_seconds_rate'
    uniques_video_viewed_25_percent_rate: "Float32" = 'uniques_video.viewed_25_percent_rate'
    uniques_video_viewed_50_percent_rate: "Float32" = 'uniques_video.viewed_50_percent_rate'
    uniques_video_viewed_75_percent_rate: "Float32" = 'uniques_video.viewed_75_percent_rate'
    uniques_video_viewed_100_percent_rate: "Float32" = 'uniques_video.viewed_100_percent_rate'
    uniques_video_depth_of_view: "Float32" = 'uniques_video.depth_of_view'